#!/usr/bin/env python3
"""
Aggiunge il disclaimer Meta/Instagram al footer di index.html di InstaScope.
Uso: python3 patch_disclaimer.py index.html
"""
import sys

if len(sys.argv) < 2:
    print("Uso: python3 patch_disclaimer.py index.html")
    sys.exit(1)

path = sys.argv[1]
with open(path, "r", encoding="utf-8") as f:
    content = f.read()

# Testo vecchio del footer (esatto, dal file originale)
OLD = """    <p style="margin-top:6px;font-size:.72rem">📧 <a href="mailto:1onlytopp@gmail.com">1onlytopp@gmail.com</a></p>
  </footer>"""

# Testo nuovo con disclaimer aggiunto
NEW = """    <p style="margin-top:6px;font-size:.72rem">📧 <a href="mailto:1onlytopp@gmail.com">1onlytopp@gmail.com</a></p>
    <p style="margin-top:10px;font-size:.72rem;color:rgba(255,255,255,.2);max-width:600px;margin-left:auto;margin-right:auto;line-height:1.6">
      InstaScope is not affiliated with, endorsed by, or connected to Meta Platforms, Inc. or Instagram.
      Instagram™ is a trademark of Meta Platforms, Inc. InstaScope is an independent tool that uses only data exported by the user from their own account.
    </p>
  </footer>"""

if OLD not in content:
    print("❌ Footer originale non trovato.")
    print("   Verifica che il file non sia già stato modificato.")
    sys.exit(1)

content = content.replace(OLD, NEW, 1)

with open(path, "w", encoding="utf-8") as f:
    f.write(content)

print("✅ Disclaimer Meta aggiunto con successo in", path)
